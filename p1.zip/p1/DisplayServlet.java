package p1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DisplayServlet
 */
public class DisplayServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String pincode = request.getParameter("pin");
		String tech = request.getParameter("techno");
		String city = new Service().getCity(pincode); 
		String job = new Service().getJobs(tech);
		
		out.print("<html><body>");
		out.print("<h3>For pincode: "+pincode+", city: "+city+"</h3>");
		out.print("<h3>For technology: "+tech+", job profile: "+job+"</h3>");
		out.print("</body></html>");
	}

}
