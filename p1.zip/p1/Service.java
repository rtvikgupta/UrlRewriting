package p1;

import java.util.ArrayList;
import java.util.HashMap;

public class Service {
	
	HashMap<String, String> hm = new HashMap<String, String>();
	{
		hm.put("110049", "Delhi");
		hm.put("420588", "Mumbai");
		hm.put("322001", "Banglore");
		hm.put("500014", "Pune");
	}
	
	public String getCity(String pincode)
	{
		String city="";
		city = hm.get(pincode);
		return city;
	}
	
	public String getJobs(String tech)
	{
		String job = "";
		if(tech.equalsIgnoreCase("Java"))
			job = ("Java Developer");
		else if(tech.equalsIgnoreCase("Angular"))
			job = ("Angular Developer");
		else if(tech.equalsIgnoreCase("Python"))
			job = "Python Developer";
		else
			job = "Oracle Developer";
		return job;
	}
}
